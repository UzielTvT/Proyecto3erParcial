// Convierte texto SQL a JSON
function sqlToJson(sql) {
    // Limpiar saltos de línea y espacios innecesarios
    sql = sql.replace(/\s+/g, ' ').trim();

    // Expresión regular para capturar INSERT INTO con múltiples filas en VALUES
    const pattern = /INSERT INTO `?(\w+)`? \((.*?)\) VALUES (.+?);/gi;

    const json = {};
    let match;

    while ((match = pattern.exec(sql)) !== null) {
        const table = match[1]; // Nombre de la tabla
        const columns = match[2].split(', ').map(col => col.trim()); // Columnas de la tabla
        const valuesBlock = match[3]; // Bloque de valores

        // Dividir el bloque de valores en filas individuales
        const rows = [...valuesBlock.matchAll(/\((.*?)\)/g)];

        rows.forEach(rowMatch => {
            const rowValues = rowMatch[1];
            const values = rowValues.split(/,\s?(?=(?:[^'"]*['"][^'"]*['"])*[^'"]*$)/).map(val => val.trim().replace(/^['"]|['"]$/g, '')); // Manejar valores con comas

            // Asociar columnas con valores en un objeto
            const row = {};
            columns.forEach((column, index) => {
                row[column] = values[index] || null;
            });

            // Añadir la fila a la tabla correspondiente
            if (!json[table]) {
                json[table] = [];
            }
            json[table].push(row);
        });
    }

    return json;
}

// Maneja la conversión de texto SQL ingresado
function convertText() {
    const sqlText = document.getElementById("sqlText").value;

    try {
        const result = sqlToJson(sqlText);
        document.getElementById("resultText").value = JSON.stringify(result, null, 4);
        document.getElementById("downloadBtn").style.display = "inline-block"; // Mostrar botón de descarga
    } catch (error) {
        console.error("Error procesando SQL:", error);
        alert("Hubo un error al procesar el texto SQL.");
    }
}

// Maneja la carga de archivos .sql desde el input
function uploadFile() {
    const fileInput = document.getElementById("sqlFile");
    const file = fileInput.files[0];

    if (file && (file.type === "application/sql" || file.name.endsWith(".sql"))) {
        const reader = new FileReader();

        reader.onload = (e) => {
            const sql = e.target.result;
            try {
                const result = sqlToJson(sql);
                document.getElementById("resultText").value = JSON.stringify(result, null, 4);
                document.getElementById("downloadBtn").style.display = "inline-block"; // Mostrar botón de descarga

                // Establecer el título del archivo automáticamente
                const titleInput = document.getElementById("fileTitle");
                titleInput.value = file.name.replace(".sql", "");
            } catch (error) {
                console.error("Error procesando SQL:", error);
                alert("Hubo un error al procesar el archivo SQL.");
            }
        };

        reader.readAsText(file);
    } else {
        alert("Por favor, sube un archivo SQL válido.");
    }
}

// Maneja la descarga del archivo JSON generado
function downloadJson() {
    const jsonContent = document.getElementById("resultText").value;
    const title = document.getElementById("fileTitle").value || "resultado"; // Título predeterminado

    const blob = new Blob([jsonContent], { type: "application/json" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `${title}.json`;
    link.click();
}

// Maneja el arrastrar y soltar archivos
const dropZone = document.getElementById("dropZone");

dropZone.addEventListener("dragover", (event) => {
    event.preventDefault();
    dropZone.classList.add("hover");
});

dropZone.addEventListener("dragleave", () => {
    dropZone.classList.remove("hover");
});

dropZone.addEventListener("drop", (event) => {
    event.preventDefault();
    dropZone.classList.remove("hover");

    const file = event.dataTransfer.files[0];
    if (file && (file.type === "application/sql" || file.name.endsWith(".sql"))) {
        const reader = new FileReader();

        reader.onload = (e) => {
            const sql = e.target.result;

            // Mostrar el contenido en el área de texto y establecer título
            document.getElementById("sqlText").value = sql;
            const titleInput = document.getElementById("fileTitle");
            titleInput.value = file.name.replace(".sql", "");

            // Procesar el texto SQL
            try {
                const result = sqlToJson(sql);
                document.getElementById("resultText").value = JSON.stringify(result, null, 4);
                document.getElementById("downloadBtn").style.display = "inline-block"; // Mostrar botón de descarga
            } catch (error) {
                console.error("Error procesando SQL:", error);
                alert("Hubo un error al procesar el archivo SQL.");
            }
        };

        reader.readAsText(file);
    } else {
        alert("Por favor, sube un archivo SQL válido.");
    }
});
